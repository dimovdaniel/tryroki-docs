=== Roki – SEO Autopilot & AI Content Writer ===
Contributors: tryroki
Tags: content sync, ai blog, integration
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 8.0
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Receive AI-generated blog posts from tryroki.com into WordPress via a secure integration key. No WordPress credentials required.

== Description ==

https://www.youtube.com/watch?v=xlDdkrMa2I0

[Tryroki](https://tryroki.com) is the WordPress receiver for the [Tryroki](https://tryroki.com) content platform. Generate blog posts and updates in the [Tryroki](https://tryroki.com) app, then publish them to your WordPress site over a secure integration — without ever sharing your WordPress username or password.

Once you paste your integration key, the plugin is fully working: articles created in the [Tryroki](https://tryroki.com) app are delivered straight to your site as WordPress posts, complete with the featured image, categories, tags, and SEO metadata. Everything received is tracked and shown in the [Tryroki](https://tryroki.com) admin dashboard.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/` or install via the WordPress admin.
2. Activate the plugin from the "Plugins" page.
3. Navigate to **Tryroki -> Manage** in your admin menu.
4. Paste the integration key generated in the [Tryroki](https://tryroki.com) app and choose whether posts publish directly or save as drafts.
5. That's it — articles created in the [Tryroki](https://tryroki.com) app now sync automatically to your site and appear on the **Tryroki -> Home** dashboard.

== External services ==

This plugin is the receiver side of an integration with the [Tryroki](https://tryroki.com) app at https://tryroki.com. No data is sent from this site; the plugin only accepts requests authenticated with the integration key configured in the [Tryroki](https://tryroki.com) app.

== Screenshots ==

1. Articles Planner: a 30-day content plan built automatically from your site's content gaps, with search volume and difficulty for every article.
2. Writing the article: SEO-optimized drafts with keyword in title, internal links, images with alt text and FAQ schema.
3. Manage your SEO with Claude: the Roki MCP connector lets your AI agent add keywords, write and schedule articles to WordPress.

== Changelog ==

= 1.1.0 =
* Documented and shipped the REST receiver endpoints (`tryroki/v1`): `/submit`, `/edit`, `/test-integration`, `/posts`, `/capabilities`.
* Incoming articles create/update WordPress posts with featured image, categories, tags, and SEO metadata (Yoast, Rank Math, AIOSEO, SEOPress, Squirrly).
* Every endpoint authenticates the integration key with a constant-time comparison, sanitizes input, and restricts post HTML via `wp_kses`.
* Received articles are recorded in the `{prefix}tryroki_manage` tracking table and surfaced on the admin dashboard.

= 1.0.0 =
* Initial scaffold release.
* Admin menu (Home + Manage) and settings page with integration key and post-mode toggle.
* Activation hook creates the `{prefix}tryroki_manage` tracking table, including multisite create/cleanup support.
* CSS, JS and icon assets adapted for the Tryroki brand.
* Helper functions for reading and caching articles from the tracking table.
