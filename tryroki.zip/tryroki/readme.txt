=== Tryroki ===
Contributors: tryroki
Tags: content sync, ai blog, integration
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 8.0
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Receive AI-generated blog posts from tryroki.com into WordPress via a secure integration key. No WordPress credentials required.

== Description ==

Tryroki is the WordPress receiver for the Tryroki content platform. Generate blog posts and updates in the Tryroki app, then publish them to your WordPress site over a secure integration — without ever sharing your WordPress username or password.

Once you paste your integration key, the plugin is fully working: articles created in the Tryroki app are delivered straight to your site as WordPress posts, complete with the featured image, categories, tags, and SEO metadata. Everything received is tracked and shown in the Tryroki admin dashboard.

**Working REST endpoints (namespace `tryroki/v1`)**

* `POST /submit` — create a new post from a payload pushed by the Tryroki app (title, content, slug, featured image, categories, tags, meta description, focus keyword, publish/draft status).
* `PUT /edit` — update an existing post; only the supplied fields are changed.
* `POST /test-integration` — verify the integration key and confirm the plugin can create and remove a post ("Test connection").
* `GET /posts` — return a paginated list of existing posts so the Tryroki app can reconcile what already lives on the site.
* `GET /capabilities` — advertise the plugin version and supported feature set.

**Security**

* Every write and reconciliation endpoint requires the integration key, checked with a constant-time `hash_equals()` comparison against the key stored on the site.
* All input is sanitized (`sanitize_text_field`, `sanitize_title`, `absint`, `esc_url_raw`) and post HTML is passed through `wp_kses` with a restricted allowlist.
* The admin settings form is protected by WordPress nonces, and admin pages require the `manage_options` capability.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/` or install via the WordPress admin.
2. Activate the plugin from the "Plugins" page.
3. Navigate to **Tryroki -> Manage** in your admin menu.
4. Paste the integration key generated in the Tryroki app and choose whether posts publish directly or save as drafts.
5. That's it — articles created in the Tryroki app now sync automatically to your site and appear on the **Tryroki -> Home** dashboard.

== External services ==

This plugin is the receiver side of an integration with the Tryroki app at https://tryroki.com. No data is sent from this site; the plugin only accepts requests authenticated with the integration key configured in the Tryroki app.

== Changelog ==

= 1.1.0 =
* Documented and shipped the REST receiver endpoints (`tryroki/v1`): `/submit`, `/edit`, `/test-integration`, `/posts`, `/capabilities`.
* Incoming articles create/update WordPress posts with featured image, categories, tags, and SEO metadata (Yoast, Rank Math, AIOSEO, SEOPress, Squirrly).
* Every endpoint authenticates the integration key with a constant-time comparison, sanitizes input, and restricts post HTML via `wp_kses`.
* Received articles are recorded in the `{prefix}tryroki_manage` tracking table and surfaced on the admin dashboard.

= 1.0.0 =
* Initial scaffold release.
* Admin menu (Home + Manage) and settings page with integration key and post-mode toggle.
* Activation hook creates the `{prefix}tryroki_manage` tracking table, including multisite create/cleanup support.
* CSS, JS and icon assets adapted for the Tryroki brand.
* Helper functions for reading and caching articles from the tracking table.
