=== Tryroki ===
Contributors: tryroki
Tags: content sync, ai blog, integration
Requires at least: 6.4
Tested up to: 6.9
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Tryroki receives AI-generated blog posts from tryroki.com directly into your WordPress site via a secure integration key — no WordPress credentials required.

== Description ==

Tryroki is the WordPress receiver for the Tryroki content platform. Generate blog posts and updates in the Tryroki app, then publish them to your WordPress site over a secure integration — without ever sharing your WordPress username or password.

This release ships the plugin scaffold: settings page, integration key storage, post-mode toggle, tracking table, and the admin dashboard. The REST receiver endpoints (`/submit`, `/edit`, `/test-integration`, `/capabilities`) ship in a follow-up release.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/` or install via the WordPress admin.
2. Activate the plugin from the "Plugins" page.
3. Navigate to **Tryroki -> Manage** in your admin menu.
4. Paste the integration key generated in the Tryroki app and select publish mode.
5. Once REST endpoints are live, articles will sync automatically from tryroki.com.

== External services ==

This plugin is the receiver side of an integration with the Tryroki app at https://tryroki.com. No data is sent from this site; the plugin only accepts requests authenticated with the integration key configured in the Tryroki app.

== Changelog ==

= 1.0.0 =
* Initial scaffold release.
* Admin menu (Home + Manage) and settings page with integration key and post-mode toggle.
* Activation hook creates the `{prefix}tryroki_manage` tracking table, including multisite create/cleanup support.
* CSS, JS and icon assets adapted for the Tryroki brand.
* Helper functions for reading and caching articles from the tracking table.
