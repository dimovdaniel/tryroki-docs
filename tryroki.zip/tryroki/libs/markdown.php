<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * Convert GFM pipe tables in $text to HTML <table> blocks. Non-table content
 * passes through unchanged. Inline markdown inside cells is limited to bold,
 * italics, inline code and links — enough to keep cell content readable
 * without pulling in a full markdown parser.
 *
 * A table block is:
 *   | header 1 | header 2 |
 *   | -------- | :------: |
 *   | row 1a   | row 1b   |
 *   | row 2a   | row 2b   |
 *
 * Outer pipes are optional in GFM; the separator row may use ":---", "---:"
 * or ":---:" to set column alignment.
 */
function tryroki_md_tables_to_html( $text ) {
    if ( $text === null || $text === '' || strpos( $text, '|' ) === false ) {
        return (string) $text;
    }

    $lines    = preg_split( '/\R/', (string) $text );
    $total    = count( $lines );
    $output   = [];
    $i        = 0;

    while ( $i < $total ) {
        if ( $i + 1 < $total
            && tryroki_md_is_table_row( $lines[ $i ] )
            && tryroki_md_is_table_separator( $lines[ $i + 1 ] ) ) {

            $header_cells = tryroki_md_split_table_row( $lines[ $i ] );
            $alignments   = tryroki_md_parse_alignments( $lines[ $i + 1 ] );

            // Header and separator must agree on column count for a valid GFM
            // table. If they don't, leave both lines as-is.
            if ( count( $header_cells ) !== count( $alignments ) ) {
                $output[] = $lines[ $i ];
                $i++;
                continue;
            }

            $body_rows = [];
            $j         = $i + 2;
            while ( $j < $total && tryroki_md_is_table_row( $lines[ $j ] ) ) {
                $body_rows[] = tryroki_md_split_table_row( $lines[ $j ] );
                $j++;
            }

            $output[] = tryroki_md_render_table( $header_cells, $alignments, $body_rows );
            $i        = $j;
            continue;
        }

        $output[] = $lines[ $i ];
        $i++;
    }

    return implode( "\n", $output );
}

function tryroki_md_is_table_row( $line ) {
    $trimmed = trim( $line );
    return $trimmed !== '' && strpos( $trimmed, '|' ) !== false;
}

function tryroki_md_is_table_separator( $line ) {
    $trimmed = trim( $line );
    if ( $trimmed === '' || strpos( $trimmed, '|' ) === false ) {
        return false;
    }
    return (bool) preg_match( '/^\|?\s*:?-{1,}:?\s*(?:\|\s*:?-{1,}:?\s*)*\|?$/', $trimmed );
}

function tryroki_md_split_table_row( $line ) {
    $trimmed = trim( $line );
    if ( $trimmed !== '' && $trimmed[0] === '|' ) {
        $trimmed = substr( $trimmed, 1 );
    }
    if ( $trimmed !== '' && substr( $trimmed, -1 ) === '|' ) {
        $trimmed = substr( $trimmed, 0, -1 );
    }
    $cells = preg_split( '/(?<!\\\\)\|/', $trimmed );
    return array_map( function ( $cell ) {
        return trim( str_replace( '\\|', '|', $cell ) );
    }, $cells );
}

function tryroki_md_parse_alignments( $separator ) {
    $cells = tryroki_md_split_table_row( $separator );
    $out   = [];
    foreach ( $cells as $cell ) {
        $cell  = trim( $cell );
        $left  = $cell !== '' && $cell[0] === ':';
        $right = $cell !== '' && substr( $cell, -1 ) === ':';
        if ( $left && $right )      { $out[] = 'center'; }
        elseif ( $right )           { $out[] = 'right';  }
        elseif ( $left )            { $out[] = 'left';   }
        else                        { $out[] = '';       }
    }
    return $out;
}

function tryroki_md_render_table( $headers, $alignments, $body_rows ) {
    $col_count = count( $headers );

    $html = "<table>\n<thead>\n<tr>";
    foreach ( $headers as $idx => $cell ) {
        $html .= '<th' . tryroki_md_align_attr( $alignments[ $idx ] ?? '' ) . '>'
              . tryroki_md_inline( $cell ) . '</th>';
    }
    $html .= "</tr>\n</thead>\n<tbody>\n";

    foreach ( $body_rows as $row ) {
        $html .= '<tr>';
        for ( $c = 0; $c < $col_count; $c++ ) {
            $cell = $row[ $c ] ?? '';
            $html .= '<td' . tryroki_md_align_attr( $alignments[ $c ] ?? '' ) . '>'
                  . tryroki_md_inline( $cell ) . '</td>';
        }
        $html .= "</tr>\n";
    }

    $html .= "</tbody>\n</table>";
    return $html;
}

function tryroki_md_align_attr( $alignment ) {
    if ( $alignment === '' ) {
        return '';
    }
    return ' style="text-align:' . $alignment . '"';
}

/**
 * Render a very small subset of inline markdown inside a table cell: bold,
 * italics, inline code, and links. Anything that looks like raw HTML is left
 * alone — wp_kses downstream is the final gatekeeper.
 */
function tryroki_md_inline( $text ) {
    $text = (string) $text;
    $text = preg_replace_callback( '/`([^`]+)`/', function ( $m ) {
        return '<code>' . $m[1] . '</code>';
    }, $text );
    $text = preg_replace_callback( '/\[([^\]]+)\]\(([^)\s]+)(?:\s+"[^"]*")?\)/', function ( $m ) {
        return '<a href="' . $m[2] . '">' . $m[1] . '</a>';
    }, $text );
    $text = preg_replace( '/\*\*(?=\S)([^*]+?)(?<=\S)\*\*/', '<strong>$1</strong>', $text );
    $text = preg_replace( '/(?<![\*\w])\*(?=\S)([^*]+?)(?<=\S)\*(?![\*\w])/', '<em>$1</em>', $text );
    return $text;
}
