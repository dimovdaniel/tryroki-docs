<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * REST namespace for all tryroki endpoints.
 */
if (!defined('TRYROKI_REST_NAMESPACE')) {
    define('TRYROKI_REST_NAMESPACE', 'tryroki/v1');
}

/**
 * Read the request secret from the `X-Secret-Key` header (or the legacy
 * lowercase variant), falling back to the JSON body `secret` field and then
 * to the `secret` query parameter, and compare it to the configured
 * `tryroki_api_key` option with `hash_equals`.
 *
 * @param WP_REST_Request $request
 * @return true|WP_REST_Response True when valid, otherwise a 403 response
 *                               with a stable error_code.
 */
function tryroki_verify_secret($request) {
    $secret = $request->get_header('X-Secret-Key');
    if (!$secret) {
        $secret = $request->get_header('x-secret-key');
    }

    if (!$secret) {
        $params = $request->get_json_params();
        if (is_array($params) && isset($params['secret'])) {
            $secret = $params['secret'];
        }
    }

    // Query-parameter fallback for GET requests that can't carry a body.
    if (!$secret) {
        $qs_secret = $request->get_param('secret');
        if (is_string($qs_secret) && $qs_secret !== '') {
            $secret = $qs_secret;
        }
    }

    $secret = is_string($secret) ? sanitize_text_field($secret) : '';
    $stored = get_option('tryroki_api_key');

    if (!$secret) {
        return new WP_REST_Response([
            'success'    => false,
            'error_code' => 'invalid_integration_key',
        ], 403);
    }

    if (!$stored) {
        return new WP_REST_Response([
            'success'    => false,
            'error_code' => 'integration_not_configured',
        ], 403);
    }

    if (!hash_equals($stored, $secret)) {
        return new WP_REST_Response([
            'success'    => false,
            'error_code' => 'invalid_integration_key',
        ], 403);
    }

    return true;
}

add_action('rest_api_init', function () {
    register_rest_route(TRYROKI_REST_NAMESPACE, '/submit', [
        'methods'             => 'POST',
        'callback'            => 'tryroki_receive_article',
        'permission_callback' => '__return_true',
    ]);

    register_rest_route(TRYROKI_REST_NAMESPACE, '/edit', [
        'methods'             => 'PUT',
        'callback'            => 'tryroki_edit_article',
        'permission_callback' => '__return_true',
    ]);

    register_rest_route(TRYROKI_REST_NAMESPACE, '/test-integration', [
        'methods'             => 'POST',
        'callback'            => 'tryroki_test_integration',
        'permission_callback' => '__return_true',
    ]);

    register_rest_route(TRYROKI_REST_NAMESPACE, '/capabilities', [
        'methods'             => 'GET',
        'callback'            => 'tryroki_get_capabilities',
        'permission_callback' => '__return_true',
    ]);

    register_rest_route(TRYROKI_REST_NAMESPACE, '/posts', [
        'methods'             => 'GET',
        'callback'            => 'tryroki_get_posts',
        'permission_callback' => '__return_true',
        'args' => [
            'page' => [
                'default'           => 1,
                'sanitize_callback' => 'absint',
            ],
            'per_page' => [
                'default'           => 500,
                'sanitize_callback' => 'absint',
            ],
            'status' => [
                'default'           => 'publish',
                'sanitize_callback' => 'sanitize_text_field',
            ],
        ],
    ]);
});

/**
 * GET /capabilities — public discovery endpoint advertising plugin version
 * and supported feature set so the tryroki app can adapt its UX.
 */
function tryroki_get_capabilities() {
    $capabilities = ['publish', 'edit', 'list'];

    $plugin_file = TRYROKI_PLUGIN_PATH . 'tryroki.php';
    $plugin_data = get_file_data($plugin_file, ['Version' => 'Version']);
    $version = !empty($plugin_data['Version']) ? $plugin_data['Version'] : TRYROKI_PLUGIN_VERSION;

    return new WP_REST_Response([
        'version'      => $version,
        'capabilities' => $capabilities,
    ], 200);
}

/**
 * POST /submit — create a new post from a payload pushed by the tryroki app.
 *
 * Expected JSON body:
 *   { title, slug?, content (HTML), meta_description?, image_url?, author?,
 *     category? (string|array), tags? (array), focus_keyword?, created_at?,
 *     status? }
 */
function tryroki_receive_article($request) {
    global $wpdb;

    $auth = tryroki_verify_secret($request);
    if ($auth !== true) return $auth;

    tryroki_ensure_table_exists();

    $params = $request->get_json_params();
    if (!is_array($params)) $params = [];

    $title      = sanitize_text_field($params['title'] ?? 'Untitled');
    $slug       = sanitize_title($params['slug'] ?? $title);
    $created_at = !empty($params['created_at'])
        ? gmdate('Y-m-d H:i:s', strtotime($params['created_at']))
        : current_time('mysql');

    $table_name = $wpdb->prefix . 'tryroki_manage';

    // Upload featured image up-front so we have an attachment ID for the row.
    $imageId = tryroki_upload_image_from_url($params['image_url'] ?? '');

    // Resolve author by ID or login. Default to user 1 when missing.
    $author    = $params['author'] ?? '';
    $author_id = 1;
    if (!empty($author)) {
        if (is_numeric($author)) {
            $author_id = (int) $author;
        } else {
            $user = get_user_by('login', $author);
            if ($user) $author_id = $user->ID;
        }
    }

    $category_ids = tryroki_resolve_category_ids($params['category'] ?? '');

    $unique_slug = tryroki_generate_unique_slug($slug, $table_name);
    if (!$unique_slug) {
        return new WP_REST_Response([
            'error' => 'Too many posts with the same slug. Please use a different slug.'
        ], 409);
    }

    $sanitized_content = tryroki_sanitize_content($params['content'] ?? '');

    // Honor explicit status override; otherwise fall back to the per-site
    // "post as draft" preference.
    $post_status = get_option('tryroki_post_as_draft', 'yes') === 'yes' ? 'draft' : 'publish';
    if (!empty($params['status'])) {
        $requested = sanitize_key($params['status']);
        $allowed   = ['publish', 'draft', 'pending', 'private', 'future'];
        if (in_array($requested, $allowed, true)) {
            $post_status = $requested;
        }
    }

    $post_id = tryroki_create_post_with_images([
        'post_title'    => $title,
        'post_content'  => $sanitized_content,
        'post_status'   => $post_status,
        'post_type'     => 'post',
        'post_name'     => $unique_slug,
        'post_category' => $category_ids,
        'tags_input'    => isset($params['tags']) ? array_map('sanitize_text_field', (array) $params['tags']) : [],
        'post_author'   => $author_id,
    ]);

    if (is_wp_error($post_id)) {
        // Clean up the uploaded image so we don't leave orphaned attachments.
        if (!empty($imageId)) {
            wp_delete_attachment($imageId, true);
        }
        return new WP_REST_Response(['error' => 'Failed to create post: ' . $post_id->get_error_message()], 500);
    }

    $final_slug  = get_post_field('post_name', $post_id);
    $final_status = get_post_field('post_status', $post_id);

    // Insert into tracking table with the actual WordPress slug.
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $inserted = $wpdb->insert($table_name, [
        'image'            => $imageId ? (string) $imageId : '',
        'slug'             => $final_slug,
        'title'            => $title,
        'meta_description' => sanitize_text_field($params['meta_description'] ?? ''),
        'status'           => $final_status,
        'created_at'       => $created_at,
    ]);

    if (!$inserted) {
        // If the tracking insert fails, roll back so we don't leave a post
        // without a corresponding row.
        $db_error = $wpdb->last_error;
        wp_delete_post($post_id, true);
        if (!empty($imageId)) {
            wp_delete_attachment($imageId, true);
        }
        return new WP_REST_Response([
            'error' => 'Failed to insert into tracking table' . ($db_error ? ': ' . $db_error : '')
        ], 500);
    }

    if (!empty($imageId)) {
        set_post_thumbnail($post_id, $imageId);
        wp_update_post([
            'ID'          => $imageId,
            'post_author' => $author_id,
            'post_parent' => $post_id,
        ]);
    }

    $focus_keyword = sanitize_text_field($params['focus_keyword'] ?? $params['focus_keyphrase'] ?? '');
    $meta_desc     = sanitize_text_field($params['meta_description'] ?? '');
    tryroki_set_seo_meta($post_id, $title, $meta_desc, $focus_keyword);
    tryroki_set_squirrly_seo($post_id, $title, $meta_desc, $focus_keyword);

    tryroki_clear_articles_cache();

    return new WP_REST_Response(['success' => true, 'post_id' => $post_id], 200);
}

/**
 * PUT /edit — update an existing post. Only the supplied fields are touched.
 *
 * Accepted body fields: id | current_slug (one required), title?, content?,
 * slug?, status?, author?, category?, tags?, image_url?, meta_description?,
 * focus_keyword?.
 */
function tryroki_edit_article($request) {
    global $wpdb;

    $auth = tryroki_verify_secret($request);
    if ($auth !== true) return $auth;

    tryroki_ensure_table_exists();

    $params = $request->get_json_params();
    if (!is_array($params)) $params = [];

    $post_id      = isset($params['id']) ? absint($params['id']) : 0;
    $current_slug = isset($params['current_slug']) ? sanitize_title($params['current_slug']) : '';

    if (!$post_id && $current_slug === '') {
        return new WP_REST_Response(['error' => 'Either id or current_slug is required'], 400);
    }

    $post = $post_id ? get_post($post_id) : get_page_by_path($current_slug, OBJECT, 'post');
    if (!$post || $post->post_type !== 'post') {
        return new WP_REST_Response(['error' => 'Post not found'], 404);
    }

    $original_slug         = $post->post_name;
    $original_thumbnail_id = (int) get_post_thumbnail_id($post->ID);
    $table_name            = $wpdb->prefix . 'tryroki_manage';

    $has_title            = array_key_exists('title', $params);
    $has_content          = array_key_exists('content', $params);
    $has_slug             = array_key_exists('slug', $params);
    $has_status           = array_key_exists('status', $params);
    $has_author           = array_key_exists('author', $params);
    $has_category         = array_key_exists('category', $params);
    $has_tags             = array_key_exists('tags', $params);
    $has_image_url        = array_key_exists('image_url', $params) && !empty($params['image_url']);
    $has_meta_description = array_key_exists('meta_description', $params) && $params['meta_description'] !== '';
    $has_focus_keyword    = array_key_exists('focus_keyword', $params) && $params['focus_keyword'] !== '';
    $has_focus_keyphrase  = array_key_exists('focus_keyphrase', $params) && $params['focus_keyphrase'] !== '';

    if (
        !$has_title && !$has_content && !$has_slug && !$has_status &&
        !$has_author && !$has_category && !$has_tags && !$has_image_url &&
        !$has_meta_description && !$has_focus_keyword && !$has_focus_keyphrase
    ) {
        return new WP_REST_Response(['error' => 'No update fields provided'], 400);
    }

    $post_update = ['ID' => $post->ID];

    if ($has_title) {
        $title = sanitize_text_field($params['title']);
        if ($title === '') {
            return new WP_REST_Response(['error' => 'Invalid title'], 400);
        }
        $post_update['post_title'] = $title;
    }

    if ($has_content) {
        $post_update['post_content'] = tryroki_sanitize_content((string) $params['content']);
    }

    if ($has_status) {
        $status = sanitize_key($params['status']);
        $allowed_statuses = ['publish', 'draft', 'pending', 'private', 'future', 'trash'];
        if (!in_array($status, $allowed_statuses, true)) {
            return new WP_REST_Response(['error' => 'Invalid status'], 400);
        }
        $post_update['post_status'] = $status;
    }

    if ($has_author) {
        $author    = $params['author'];
        $author_id = 0;

        if (is_numeric($author)) {
            $author_id = absint($author);
            if ($author_id && !get_userdata($author_id)) {
                return new WP_REST_Response(['error' => 'Invalid author'], 400);
            }
        } else {
            $user = get_user_by('login', sanitize_user((string) $author, true));
            if (!$user) {
                return new WP_REST_Response(['error' => 'Invalid author'], 400);
            }
            $author_id = (int) $user->ID;
        }

        if (!$author_id) {
            return new WP_REST_Response(['error' => 'Invalid author'], 400);
        }

        $post_update['post_author'] = $author_id;
    }

    if ($has_category) {
        $post_update['post_category'] = tryroki_resolve_category_ids($params['category']);
    }

    if ($has_tags) {
        $tags = is_array($params['tags']) ? $params['tags'] : [$params['tags']];
        $post_update['tags_input'] = array_map('sanitize_text_field', $tags);
    }

    if ($has_slug) {
        $new_slug = sanitize_title($params['slug']);
        if ($new_slug === '') {
            return new WP_REST_Response(['error' => 'Invalid slug'], 400);
        }

        if ($new_slug !== $original_slug && tryroki_slug_exists_for_other_post($new_slug, $post->ID, $original_slug)) {
            return new WP_REST_Response(['error' => 'Slug already exists'], 409);
        }

        $post_update['post_name'] = $new_slug;
    }

    $new_thumbnail_id      = 0;
    $existing_attachment_id = 0;
    if ($has_image_url) {
        $image_url = esc_url_raw((string) $params['image_url']);
        if (!$image_url) {
            return new WP_REST_Response(['error' => 'Invalid image_url'], 400);
        }

        $existing_attachment_id = tryroki_find_attachment_by_source_url($image_url);
        if ($existing_attachment_id) {
            $new_thumbnail_id = $existing_attachment_id;
        } else {
            $new_thumbnail_id = (int) tryroki_upload_image_from_url($image_url, $post->ID);
            if (!$new_thumbnail_id) {
                return new WP_REST_Response(['error' => 'Failed to upload image'], 500);
            }
        }
    }

    $warnings = [];

    // Bypass wp_kses during update so we don't double-sanitize HTML we've
    // already cleaned via tryroki_sanitize_content().
    kses_remove_filters();
    try {
        $updated_post_id = wp_update_post($post_update, true);
        if (is_wp_error($updated_post_id)) {
            throw new RuntimeException($updated_post_id->get_error_message());
        }
    } catch (RuntimeException $e) {
        kses_init_filters();
        if ($new_thumbnail_id && !$existing_attachment_id) {
            wp_delete_attachment($new_thumbnail_id, true);
        }
        return new WP_REST_Response(['error' => 'Failed to update post: ' . $e->getMessage()], 500);
    }

    if ($has_content) {
        $saved_content     = isset($post_update['post_content']) ? $post_update['post_content'] : get_post_field('post_content', $post->ID);
        $localized_content = tryroki_download_content_images($saved_content, $post->ID);

        if ($localized_content !== $saved_content) {
            $content_update_result = wp_update_post([
                'ID'           => $post->ID,
                'post_content' => $localized_content,
            ], true);

            if (is_wp_error($content_update_result)) {
                $warnings[] = 'Content images could not be localized.';
            }
        }
    }

    kses_init_filters();

    if ($new_thumbnail_id) {
        if (!set_post_thumbnail($post->ID, $new_thumbnail_id)) {
            $warnings[] = 'Featured image could not be assigned.';
        }

        $final_post = get_post($post->ID);
        if ($final_post && !$existing_attachment_id) {
            $attachment_update_result = wp_update_post([
                'ID'          => $new_thumbnail_id,
                'post_author' => (int) $final_post->post_author,
                'post_parent' => $post->ID,
            ], true);

            if (is_wp_error($attachment_update_result)) {
                $warnings[] = 'Featured image metadata could not be updated.';
            }
        }

        // Garbage-collect the previous featured image if it was a tryroki
        // download and isn't reused by another post.
        if (
            $original_thumbnail_id &&
            $original_thumbnail_id !== $new_thumbnail_id &&
            get_post_meta($original_thumbnail_id, '_tryroki_source_url', true) &&
            !tryroki_attachment_is_featured_elsewhere($original_thumbnail_id, $post->ID)
        ) {
            wp_delete_attachment($original_thumbnail_id, true);
        }
    }

    $final_post = get_post($post->ID);
    if (!$final_post) {
        return new WP_REST_Response(['error' => 'Post not found after update'], 500);
    }

    $final_title       = $final_post->post_title;
    $final_status      = $final_post->post_status;
    $final_slug        = $final_post->post_name;
    $tracking_slug     = tryroki_normalize_tracking_slug($final_slug);
    $final_thumbnail_id = (int) get_post_thumbnail_id($post->ID);

    if ($has_title || $has_meta_description || $has_focus_keyword || $has_focus_keyphrase) {
        $meta_description = $has_meta_description ? sanitize_text_field($params['meta_description']) : null;
        $focus_keyword    = null;

        if ($has_focus_keyword) {
            $focus_keyword = sanitize_text_field($params['focus_keyword']);
        } elseif ($has_focus_keyphrase) {
            $focus_keyword = sanitize_text_field($params['focus_keyphrase']);
        }

        tryroki_set_seo_meta($post->ID, $has_title ? $final_title : null, $meta_description, $focus_keyword);
        tryroki_set_squirrly_seo($post->ID, $has_title ? $final_title : null, $meta_description, $focus_keyword);
    }

    $original_tracking_slug = tryroki_normalize_tracking_slug($original_slug);

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $tracking_row = $wpdb->get_row($wpdb->prepare(
        "SELECT id FROM {$table_name} WHERE slug = %s OR slug = %s LIMIT 1",
        $original_slug,
        $original_tracking_slug
    ));

    if ($tracking_row) {
        $tracking_update = [
            'slug'   => $tracking_slug,
            'title'  => $final_title,
            'status' => $final_status,
            'image'  => $final_thumbnail_id ? (string) $final_thumbnail_id : '',
        ];

        if ($has_meta_description) {
            $tracking_update['meta_description'] = sanitize_text_field($params['meta_description']);
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->update(
            $table_name,
            $tracking_update,
            ['id' => (int) $tracking_row->id]
        );
    }

    tryroki_clear_articles_cache();

    $response = [
        'success' => true,
        'post_id' => $post->ID,
    ];

    if (!empty($warnings)) {
        $response['warnings'] = array_values(array_unique($warnings));
    }

    return new WP_REST_Response($response, 200);
}

/**
 * POST /test-integration — verify the secret and confirm we can create and
 * delete a post. Used by the tryroki app's "Test connection" button.
 */
function tryroki_test_integration($request) {
    $auth = tryroki_verify_secret($request);
    if ($auth !== true) return $auth;

    $test_post_id = wp_insert_post([
        'post_title'   => 'Test Post - Tryroki Integration',
        'post_content' => 'This is a test post to verify Tryroki integration is working correctly.',
        'post_status'  => 'draft',
        'post_type'    => 'post',
        'post_name'    => 'tryroki-test-post-' . time(),
        'post_author'  => 1,
    ]);

    if (is_wp_error($test_post_id)) {
        return new WP_REST_Response([
            'success'    => false,
            'error_code' => 'post_creation_failed',
        ], 500);
    }

    // Force-delete the test post — cleanup failure shouldn't fail the test.
    wp_delete_post($test_post_id, true);

    return new WP_REST_Response([
        'success' => true,
        'message' => 'Integration test successful',
    ], 200);
}

/**
 * GET /posts — paginated list of existing posts for reconciliation.
 *
 * Accepts the secret via the `X-Secret-Key` header or `secret` query
 * parameter.
 */
function tryroki_get_posts($request) {
    $auth = tryroki_verify_secret($request);
    if ($auth !== true) return $auth;

    $page = (int) $request->get_param('page');
    if ($page < 1) $page = 1;
    $per_page = (int) $request->get_param('per_page');
    if ($per_page < 1) $per_page = 1;
    $per_page = min($per_page, 500);
    $status   = $request->get_param('status');

    $allowed_statuses = ['publish', 'draft', 'private', 'pending', 'future', 'trash'];
    if (!in_array($status, $allowed_statuses, true)) {
        $status = 'publish';
    }

    $query = new WP_Query([
        'post_type'      => 'post',
        'post_status'    => $status,
        'posts_per_page' => $per_page,
        'paged'          => $page,
        'orderby'        => 'date',
        'order'          => 'DESC',
    ]);

    $posts = [];
    foreach ($query->posts as $post) {
        $categories     = wp_get_post_categories($post->ID, ['fields' => 'names']);
        $tags           = wp_get_post_tags($post->ID, ['fields' => 'names']);
        $featured_image = get_the_post_thumbnail_url($post->ID, 'full');

        $posts[] = [
            'id'             => $post->ID,
            'title'          => $post->post_title,
            'slug'           => $post->post_name,
            'content'        => $post->post_content,
            'excerpt'        => $post->post_excerpt ?: wp_trim_words($post->post_content, 55),
            'status'         => $post->post_status,
            'date'           => $post->post_date,
            'modified'       => $post->post_modified,
            'categories'     => $categories,
            'tags'           => $tags,
            'featured_image' => $featured_image ?: null,
            'url'            => get_permalink($post->ID),
        ];
    }

    return new WP_REST_Response([
        'success' => true,
        'posts'   => $posts,
        'pagination' => [
            'page'        => $page,
            'per_page'    => $per_page,
            'total_posts' => (int) $query->found_posts,
            'total_pages' => (int) $query->max_num_pages,
        ],
    ], 200);
}

// --- Helper functions ----------------------------------------------------

/**
 * Locate an attachment previously downloaded from a given source URL.
 *
 * @param string $image_url
 * @return int Attachment ID or 0 when not found.
 */
function tryroki_find_attachment_by_source_url($image_url) {
    $existing = get_posts([
        'post_type'   => 'attachment',
        'meta_key'    => '_tryroki_source_url', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
        'meta_value'  => $image_url, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
        'numberposts' => 1,
        'fields'      => 'ids',
    ]);

    if (empty($existing)) {
        return 0;
    }

    return (int) $existing[0];
}

/**
 * Check whether an attachment is used as the featured image of any post
 * other than the one we're about to update.
 */
function tryroki_attachment_is_featured_elsewhere($attachment_id, $exclude_post_id = 0) {
    global $wpdb;

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $count = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->postmeta} pm
        INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
        WHERE pm.meta_key = '_thumbnail_id'
        AND pm.meta_value = %d
        AND p.post_type = 'post'
        AND p.ID != %d",
        $attachment_id,
        $exclude_post_id
    ));

    return (int) $count > 0;
}

/**
 * WordPress appends `__trashed` to a slug when a post is moved to trash.
 * Tracking rows should still match the human-meaningful slug, so strip the
 * suffix before comparing or storing.
 */
function tryroki_normalize_tracking_slug($slug) {
    return preg_replace('/__trashed$/', '', (string) $slug);
}

/**
 * Return true when the given slug is already used by a different post or
 * a different tracking row.
 */
function tryroki_slug_exists_for_other_post($slug, $post_id, $original_slug) {
    global $wpdb;

    $table_name             = $wpdb->prefix . 'tryroki_manage';
    $original_tracking_slug = tryroki_normalize_tracking_slug($original_slug);

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $wp_conflict = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_name = %s AND post_type = 'post' AND ID != %d",
        $slug,
        $post_id
    ));

    if ((int) $wp_conflict > 0) {
        return true;
    }

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $table_conflict = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$table_name} WHERE slug = %s AND slug NOT IN (%s, %s)",
        $slug,
        $original_slug,
        $original_tracking_slug
    ));

    return (int) $table_conflict > 0;
}

/**
 * wp_kses content with a YouTube iframe allowlist — matches outrank.
 */
function tryroki_sanitize_content($content) {
    $allowed_html = wp_kses_allowed_html('post');

    $allowed_html['iframe'] = [
        'src'             => [],
        'width'           => [],
        'height'          => [],
        'frameborder'     => [],
        'allowfullscreen' => [],
        'allow'           => [],
        'style'           => [],
    ];

    $sanitized = wp_kses($content, $allowed_html);

    // Strip every iframe except YouTube embeds (covers youtube.com and
    // youtube-nocookie.com with an 11-char video ID).
    $sanitized = preg_replace_callback(
        '/<iframe[^>]*>/i',
        function ($matches) {
            $iframe = $matches[0];

            if (preg_match('/src=["\']([^"\']*)["\']/', $iframe, $src_matches)) {
                $src = trim($src_matches[1]);

                if (preg_match('/^https:\/\/(www\.)?youtube\.com\/embed\/[a-zA-Z0-9_-]{11}(\?[^"\'<>]*)?$/i', $src) ||
                    preg_match('/^https:\/\/(www\.)?youtube-nocookie\.com\/embed\/[a-zA-Z0-9_-]{11}(\?[^"\'<>]*)?$/i', $src)) {
                    return $iframe;
                }
            }

            return '';
        },
        $sanitized
    );

    return $sanitized;
}

/**
 * Resolve category names/slugs to term IDs, creating missing categories on
 * the fly. Falls back to the default category (ID 1) when nothing matches.
 */
function tryroki_resolve_category_ids($category) {
    $category_ids = [];
    if (!empty($category)) {
        $categories = is_array($category) ? $category : [$category];
        foreach ($categories as $cat_name) {
            $cat_name = sanitize_text_field($cat_name);
            $cat      = get_category_by_slug(sanitize_title($cat_name));
            if (!$cat) {
                $term = wp_insert_term($cat_name, 'category');
                if (!is_wp_error($term)) {
                    $category_ids[] = $term['term_id'];
                } else {
                    $category_ids[] = 1;
                }
            } else {
                $category_ids[] = $cat->term_id;
            }
        }
    } else {
        $category_ids[] = 1;
    }
    return $category_ids;
}

/**
 * Return a slug guaranteed to be unique across both WordPress posts and the
 * tryroki tracking table. Returns false after 10 attempts.
 */
function tryroki_generate_unique_slug($slug, $table_name) {
    global $wpdb;
    $max_attempts = 10;
    for ($i = 0; $i < $max_attempts; $i++) {
        $test_slug = ($i === 0) ? $slug : $slug . '-' . ($i + 1);
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $in_custom = $wpdb->get_var(
            $wpdb->prepare("SELECT COUNT(*) FROM %i WHERE slug = %s", $table_name, $test_slug)
        );
        $in_wp = get_page_by_path($test_slug, OBJECT, 'post');
        if ($in_custom == 0 && !$in_wp) {
            return $test_slug;
        }
    }
    return false;
}

/**
 * Write meta values across the major SEO plugins so the new post is picked
 * up regardless of which one the site uses.
 */
function tryroki_set_seo_meta($post_id, $title = null, $meta_description = null, $focus_keyword = null) {
    if ($meta_description !== null && $meta_description !== '') {
        update_post_meta($post_id, '_yoast_wpseo_metadesc', $meta_description);
        update_post_meta($post_id, 'rank_math_description', $meta_description);
        update_post_meta($post_id, '_aioseo_description', $meta_description);
        update_post_meta($post_id, '_seopress_titles_desc', $meta_description);
    }
    if ($focus_keyword !== null && $focus_keyword !== '') {
        update_post_meta($post_id, '_yoast_wpseo_focuskw', $focus_keyword);
        update_post_meta($post_id, 'rank_math_focus_keyword', $focus_keyword);
        update_post_meta($post_id, '_aioseo_keyphrases', wp_json_encode([
            ['keyphrase' => $focus_keyword, 'score' => 0]
        ]));
        update_post_meta($post_id, '_seopress_analysis_target_kw', $focus_keyword);
    }
    if ($title !== null && $title !== '') {
        update_post_meta($post_id, '_yoast_wpseo_title', $title);
        update_post_meta($post_id, 'rank_math_title', $title);
        update_post_meta($post_id, '_aioseo_title', $title);
        update_post_meta($post_id, '_seopress_titles_title', $title);
    }
}

/**
 * Squirrly SEO stores its data in a custom table, so we update/insert there
 * directly rather than going through post meta.
 */
function tryroki_set_squirrly_seo($post_id, $title = null, $meta_description = null, $focus_keyword = null) {
    global $wpdb;
    $sq_table = $wpdb->prefix . 'qss';
    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $sq_table)) !== $sq_table) return;

    $url_hash = md5(strval($post_id));

    $sq_defaults = [
        'doseo' => 1, 'noindex' => 0, 'nofollow' => 0, 'nositemap' => 0,
        'title' => '', 'description' => '', 'keywords' => '',
        'canonical' => '', 'primary_category' => '',
        'redirect' => '', 'redirect_type' => 301,
        'robots' => null, 'focuspage' => null,
        'tw_media' => '', 'tw_title' => '', 'tw_description' => '', 'tw_type' => '',
        'og_title' => '', 'og_description' => '', 'og_author' => '', 'og_type' => '', 'og_media' => '',
        'jsonld' => '', 'jsonld_types' => [], 'fpixel' => '',
        'patterns' => null, 'sep' => null, 'optimizations' => null, 'innerlinks' => null,
    ];

    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
    $existing = $wpdb->get_row($wpdb->prepare(
        "SELECT id, seo FROM %i WHERE url_hash = %s",
        $sq_table,
        $url_hash
    ));

    if ($existing) {
        $seo_data = maybe_unserialize($existing->seo);
        if (!is_array($seo_data)) {
            $seo_data = $sq_defaults;
        }
    } else {
        $seo_data = $sq_defaults;
    }

    if ($title !== null) {
        $seo_data['title'] = $title;
    }
    if ($meta_description !== null) {
        $seo_data['description'] = $meta_description;
    }
    if ($focus_keyword !== null) {
        $seo_data['keywords'] = $focus_keyword;
    }
    $seo_data['doseo'] = 1;

    if ($existing) {
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->update($sq_table, [
            'seo'       => serialize($seo_data),
            'date_time' => current_time('mysql'),
        ], ['id' => $existing->id]);
    } else {
        $post_url = get_permalink($post_id);
        $post_obj = serialize([
            'ID' => $post_id, 'post_type' => 'post', 'term_id' => 0, 'taxonomy' => '',
        ]);
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->insert($sq_table, [
            'blog_id'   => get_current_blog_id(),
            'post'      => $post_obj,
            'URL'       => $post_url,
            'url_hash'  => $url_hash,
            'seo'       => serialize($seo_data),
            'date_time' => current_time('mysql'),
        ]);
    }
}

/**
 * Insert a post, then walk its content and pull every remote image into the
 * local media library so it stops depending on the source host.
 *
 * Disables kses around the insert + content rewrite, then re-enables it, so
 * we don't double-sanitize HTML we've already cleaned.
 */
function tryroki_create_post_with_images($args) {
    kses_remove_filters();

    $post_id = wp_insert_post($args);

    if (is_wp_error($post_id)) {
        kses_init_filters();
        return $post_id;
    }

    $updated_content = tryroki_download_content_images($args['post_content'], $post_id);
    if ($updated_content !== $args['post_content']) {
        wp_update_post([
            'ID'           => $post_id,
            'post_content' => $updated_content,
        ]);
    }

    kses_init_filters();
    return $post_id;
}
