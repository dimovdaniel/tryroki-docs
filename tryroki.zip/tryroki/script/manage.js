// Initialize plugin settings
let tryrokiPluginSettings = {
    apiKey: document.getElementById('api_key')?.value.trim() || '',
};

// Load settings on page load
function tryrokiLoadSettings() {
    const input = document.getElementById('api_key');
    if (input) tryrokiPluginSettings.apiKey = input.value.trim();
    updateStatus();
}

// Display a notification message
function tryrokiShowNotice(message, type = 'success') {
    const notice = document.getElementById('notice');
    const messageSpan = document.getElementById('notice-message');

    if (!notice || !messageSpan) return;

    notice.className = `notice notice-${type}`;
    messageSpan.textContent = message;
    notice.style.display = 'block';

    setTimeout(() => {
        notice.style.display = 'none';
    }, 4000);
}

// Update status badge based on API key
function updateStatus() {
    const status = document.getElementById('fetch-status');
    if (!status) return;

    if (tryrokiPluginSettings.apiKey) {
        status.textContent = 'Connected';
        status.className = 'status-badge active';
    } else {
        status.textContent = 'Not Connected';
        status.className = 'status-badge inactive';
    }
}

// Client-side validation only — block submit when the key is empty so the
// browser still posts the submit button (and PHP runs update_option).
// Calling form.submit() ourselves would strip the submit button from POST data,
// which is what was breaking persistence before.
document.getElementById('api-form')?.addEventListener('submit', function (e) {
    const apiKey = document.getElementById('api_key')?.value.trim() || '';
    if (!apiKey) {
        e.preventDefault();
        tryrokiShowNotice('Please enter an integration key', 'error');
        return;
    }

    // Defer the visual "Saving..." state to the next tick so the submit
    // button's name/value is still included in the POST body.
    const saveBtn = document.getElementById('save-btn');
    if (saveBtn) {
        setTimeout(() => {
            saveBtn.disabled = true;
            saveBtn.textContent = 'Saving...';
        }, 0);
    }
});

// Load initial settings
tryrokiLoadSettings();
