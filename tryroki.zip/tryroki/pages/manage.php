<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

// Handle API key form submission
if (isset($_POST['btn_save_and_sync'])) {
    // Nonce verification
    check_admin_referer('tryroki_save_key');

    // Securely handle input
    $tryroki_api_key = isset($_POST['api_key']) ? sanitize_text_field(wp_unslash($_POST['api_key'])) : '';
    $tryroki_post_mode = isset($_POST['post_as_draft']) ? sanitize_text_field(wp_unslash($_POST['post_as_draft'])) : 'no';

    if (!in_array($tryroki_post_mode, ['yes', 'no'], true)) {
        $tryroki_post_mode = 'no'; // fallback
    }

    update_option('tryroki_api_key', $tryroki_api_key);
    update_option('tryroki_post_as_draft', $tryroki_post_mode);

    echo '<div class="tryroki-success-notice">
            <div class="notice-content">
                <svg class="notice-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M9 12l2 2 4-4M21 12c0 4.97-4.03 9-9 9s-9-4.03-9-9 4.03-9 9-9 9 4.03 9 9z"/>
                </svg>
                <div>
                    <div class="notice-title">Settings Saved Successfully!</div>
                    <div class="notice-subtitle">Integration key and preferences updated successfully.</div>
                </div>
            </div>
          </div>';
}

// Get saved values
$tryroki_api_key = get_option('tryroki_api_key');
$tryroki_is_draft = get_option('tryroki_post_as_draft', 'no');
$tryroki_is_connected = !empty($tryroki_api_key);
?>

<div class="tryroki-settings-container">
    <div class="tryroki-settings-card">
        <div class="tryroki-settings-header">
            <div class="tryroki-brand">
                <img src="<?php echo esc_url(TRYROKI_PLUGIN_URL . 'images/roki_head.png'); ?>" alt="Roki" class="tryroki-brand-logo" />
                <span class="tryroki-brand-name">Roki</span>
            </div>
            <h1 class="settings-title"><?php echo empty($tryroki_api_key) ? 'Connect your Roki account' : 'Plugin settings'; ?></h1>
            <p class="settings-subtitle">Configure the Tryroki plugin to receive articles from tryroki.com</p>
            <div class="connection-status">
                <span id="fetch-status" class="status-badge <?php echo $tryroki_is_connected ? 'active' : 'inactive'; ?>">
                    <?php echo $tryroki_is_connected ? 'Connected' : 'Not Connected'; ?>
                </span>
            </div>
        </div>

        <div class="settings-form-container">
            <form id="api-form" method="post" action="<?php echo esc_url(admin_url('admin.php?page=tryroki_manage')); ?>" class="settings-form">
                <?php wp_nonce_field('tryroki_save_key'); ?>

                <div class="field-group">
                    <label for="api_key" class="field-label">Integration Key</label>
                    <input
                        type="text"
                        id="api_key"
                        name="api_key"
                        class="field-input"
                        value="<?php echo esc_attr($tryroki_api_key); ?>"
                        placeholder="Paste your Tryroki integration key here..."
                        required
                    />
                    <p class="field-description">
                        Generate this key in the <a href="https://tryroki.com/" target="_blank" rel="noopener noreferrer">Tryroki app</a> when creating your WordPress integration.
                    </p>
                </div>

                <div class="field-group">
                    <label for="post_as_draft" class="field-label">Post Mode</label>
                    <select name="post_as_draft" id="post_as_draft" class="field-input">
                        <option value="" disabled>Select Post Mode</option>
                        <option value="yes" <?php selected($tryroki_is_draft, 'yes'); ?>>Save as Draft</option>
                        <option value="no" <?php selected($tryroki_is_draft, 'no'); ?>>Publish Directly</option>
                    </select>
                    <p class="field-description">Choose whether incoming posts are published immediately or saved as drafts.</p>
                </div>

                <div class="flex-buttons" style="display: flex; gap: 12px; margin-top: 16px;">
                    <button id="save-btn" type="submit" name="btn_save_and_sync" class="save-button">
                        Save
                    </button>
                </div>
            </form>

            <div id="notice" class="notice" style="display:none;">
                <span id="notice-message"></span>
            </div>
        </div>
    </div>
</div>
