<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if (!function_exists('tryroki_render_image')) :
function tryroki_render_image($attachment_id, $alt = 'Post thumbnail') {
    if (!$attachment_id || !is_numeric($attachment_id)) {
        return '<div class="no-image">No image</div>';
    }

    return wp_get_attachment_image((int) $attachment_id, 'full', false, [
        'alt'   => esc_attr($alt),
        'class' => 'custom-thumbnail',
    ]);
}
endif;

$tryroki_articles = tryroki_get_articles();

$tryroki_per_page = 10;
$tryroki_total = count($tryroki_articles);
$tryroki_total_pages = (int) ceil($tryroki_total / $tryroki_per_page);
// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only pagination on admin page
$tryroki_paged = isset($_GET['paged']) ? max(1, (int) $_GET['paged']) : 1;
if ($tryroki_paged > $tryroki_total_pages && $tryroki_total_pages > 0) {
    $tryroki_paged = $tryroki_total_pages;
}
$tryroki_offset = ($tryroki_paged - 1) * $tryroki_per_page;
$tryroki_paged_articles = array_slice($tryroki_articles, $tryroki_offset, $tryroki_per_page);
?>

<div class="tryroki-container">
    <div class="tryroki-card">
        <div class="tryroki-header">
            <div class="tryroki-title-wrap">
                <img src="<?php echo esc_url(TRYROKI_PLUGIN_URL . 'images/roki_head.png'); ?>" alt="Roki" class="tryroki-brand-logo" />
                <div>
                    <h2 class="tryroki-title">Roki Dashboard</h2>
                    <p class="tryroki-subtitle">Articles received from tryroki.com</p>
                </div>
            </div>
            <form method="get" style="margin: 0;">
                <input type="hidden" name="page" value="tryroki_manage">
                <button type="submit" class="tryroki-fetch-btn">
                    Settings
                </button>
            </form>
        </div>

        <div class="tryroki-table-container">
            <?php if (!empty($tryroki_articles)) : ?>
                <table class="tryroki-table">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Slug</th>
                            <th>Meta Description</th>
                            <th>Image</th>
                            <th>Status</th>
                            <th>Created</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($tryroki_paged_articles as $post) : ?>
                            <tr>
                                <td>
                                    <div class="post-title">
                                        <?php echo esc_html($post->title); ?>
                                    </div>
                                </td>
                                <td>
                                    <span class="post-slug">
                                        <?php echo esc_html($post->slug); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="post-meta">
                                        <?php echo esc_html(wp_trim_words($post->meta_description, 12)); ?>
                                    </div>
                                </td>
                                <td>
                                    <div class="post-image">
                                    <?php echo wp_kses_post(tryroki_render_image($post->image)); ?>
                                    </div>
                                </td>
                                <td>
                                    <span class="status-badge status-<?php echo esc_attr(strtolower($post->status)); ?>">
                                        <?php echo esc_html(ucfirst($post->status)); ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="post-date">
                                        <?php echo esc_html(date_i18n('M j, Y', strtotime($post->created_at))); ?>
                                        <br>
                                        <small style="opacity: 0.7;">
                                            <?php echo esc_html(date_i18n('g:i a', strtotime($post->created_at))); ?>
                                        </small>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php if ($tryroki_total_pages > 1) : ?>
                    <div class="tryroki-pagination">
                        <span class="pagination-info">
                            Showing <?php echo esc_html($tryroki_offset + 1); ?>–<?php echo esc_html(min($tryroki_offset + $tryroki_per_page, $tryroki_total)); ?> of <?php echo esc_html($tryroki_total); ?> articles
                        </span>
                        <div class="pagination-links">
                            <?php if ($tryroki_paged > 1) : ?>
                                <a href="<?php echo esc_url(admin_url('admin.php?page=tryroki&paged=' . ($tryroki_paged - 1))); ?>" class="pagination-btn pagination-prev">&lsaquo; Previous</a>
                            <?php else : ?>
                                <span class="pagination-btn pagination-prev pagination-disabled">&lsaquo; Previous</span>
                            <?php endif; ?>
                            <?php
                            $tryroki_range = 2;
                            for ($tryroki_i = 1; $tryroki_i <= $tryroki_total_pages; $tryroki_i++) :
                                if ($tryroki_i === 1 || $tryroki_i === $tryroki_total_pages || ($tryroki_i >= $tryroki_paged - $tryroki_range && $tryroki_i <= $tryroki_paged + $tryroki_range)) :
                                    if ($tryroki_i === $tryroki_paged) : ?>
                                        <span class="pagination-btn pagination-current"><?php echo esc_html($tryroki_i); ?></span>
                                    <?php else : ?>
                                        <a href="<?php echo esc_url(admin_url('admin.php?page=tryroki&paged=' . $tryroki_i)); ?>" class="pagination-btn"><?php echo esc_html($tryroki_i); ?></a>
                                    <?php endif;
                                elseif ($tryroki_i === 2 || $tryroki_i === $tryroki_total_pages - 1) : ?>
                                    <span class="pagination-ellipsis">&hellip;</span>
                                <?php endif;
                            endfor;
                            ?>
                            <?php if ($tryroki_paged < $tryroki_total_pages) : ?>
                                <a href="<?php echo esc_url(admin_url('admin.php?page=tryroki&paged=' . ($tryroki_paged + 1))); ?>" class="pagination-btn pagination-next">Next &rsaquo;</a>
                            <?php else : ?>
                                <span class="pagination-btn pagination-next pagination-disabled">Next &rsaquo;</span>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php else : ?>
                <div class="empty-state">
                    <div class="empty-state-text">No blog posts found</div>
                    <div class="empty-state-subtext">Publish your first article in the Tryroki app to see it here</div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
